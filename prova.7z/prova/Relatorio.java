package prova;

public interface Relatorio {
    void gerar(String conteudo);
}
