package Injecao_de_dependencia;

public interface iMetodo_pgto {
    Boolean executar_pgto();
}
